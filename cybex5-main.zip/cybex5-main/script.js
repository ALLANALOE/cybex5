document.addEventListener("DOMContentLoaded", function() {
    // Display loading animation for 3 seconds, then redirect to the main page
    setTimeout(function() {
        window.location.href = "page.html"; // Redirect to the main page
    }, 3000); // 3000 milliseconds = 3 seconds
});
