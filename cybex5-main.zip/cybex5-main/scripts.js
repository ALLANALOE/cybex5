document.addEventListener("DOMContentLoaded", function() {
    // Show loading animation for 3 seconds
    setTimeout(function() {
        document.getElementById('cybex5-intro').style.display = 'none';
        document.getElementById('main-content').style.display = 'block';
    }, 3000); // 3000 milliseconds = 3 seconds
});
